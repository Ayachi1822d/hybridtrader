class IBKR:
    def place_order(self, order): return "ok"
