class FIXEngine:
    def connect(self): pass
    def send_order(self, order): print("FIX:", order)
