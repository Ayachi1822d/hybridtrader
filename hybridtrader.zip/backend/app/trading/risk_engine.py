def check_risk(order):
    return True
