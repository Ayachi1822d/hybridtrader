def submit_order(symbol, side, qty, price=None):
    return {
        "symbol": symbol,
        "side": side,
        "qty": qty,
        "status": "submitted"
    }
