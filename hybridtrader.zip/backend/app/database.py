from sqlalchemy import create_engine

engine = create_engine(
    "sqlite:///./hybridtrader.db",
    connect_args={"check_same_thread": False}
)
