from fastapi import FastAPI
from app.api import auth, markets, orders, portfolio, risk
from app.ws.prices import router as ws_router

app = FastAPI(title="HybridTrader")

app.include_router(auth.router, prefix="/api/auth")
app.include_router(markets.router, prefix="/api/markets")
app.include_router(orders.router, prefix="/api/orders")
app.include_router(portfolio.router, prefix="/api/portfolio")
app.include_router(risk.router, prefix="/api/risk")
app.include_router(ws_router)
