class User:
    def __init__(self, email): self.email = email
