class Account:
    def __init__(self, balance): self.balance = balance
