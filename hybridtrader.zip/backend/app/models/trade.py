class Trade:
    def __init__(self, symbol, qty): pass
