from fastapi import APIRouter
router = APIRouter()

@router.get("/")
def portfolio():
    return {"balance": 61528.74}
