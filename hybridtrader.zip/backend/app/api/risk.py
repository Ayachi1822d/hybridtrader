from fastapi import APIRouter
router = APIRouter()

@router.get("/")
def risk():
    return {"exposure": 52097}
