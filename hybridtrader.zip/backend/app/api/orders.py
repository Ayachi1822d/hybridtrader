from fastapi import APIRouter
from app.trading.engine import submit_order

router = APIRouter()

@router.post("/")
def place(order: dict):
    return submit_order(**order)
