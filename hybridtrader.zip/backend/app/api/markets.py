from fastapi import APIRouter
router = APIRouter()

@router.get("/")
def markets():
    return ["EURUSD", "GBPUSD", "US100"]
