from fastapi import APIRouter, WebSocket
import asyncio, json

router = APIRouter()

@router.websocket("/ws/prices")
async def prices(ws: WebSocket):
    await ws.accept()
    while True:
        await ws.send_text(json.dumps({
            "symbol": "EURUSD",
            "price": 1.0852
        }))
        await asyncio.sleep(1)
