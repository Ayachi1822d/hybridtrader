const API_BASE = "https://hybridtrader-api.wispbyte.app";

async function api(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, options);
  return res.json();
}
