const ws = new WebSocket(
  "wss://hybridtrader-api.wispbyte.app/ws/prices"
);
