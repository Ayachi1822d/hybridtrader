console.log("CEOOOOO HybridTrader UI loaded");
