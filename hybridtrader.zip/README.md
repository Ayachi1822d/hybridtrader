# HybridTrader

HybridTrader is a professional trading platform architecture for
stocks + forex using:
- Plain HTML/CSS/JS frontend
- FastAPI backend
- WebSockets for live prices
- Broker adapters (FIX / REST)

⚠️ This is an educational / engineering foundation.
Live trading requires broker approval & compliance.
